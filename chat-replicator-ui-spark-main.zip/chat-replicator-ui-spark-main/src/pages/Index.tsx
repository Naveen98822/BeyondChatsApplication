
import { useState } from "react";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { Header } from "@/components/Header";
import { ChatInterface } from "@/components/ChatInterface";
import { ConversationList } from "@/components/ConversationList";
import { CustomerProfile } from "@/components/CustomerProfile";
import { Analytics } from "@/components/Analytics";
import { Settings } from "@/components/Settings";

const Index = () => {
  const [activeView, setActiveView] = useState("conversations");
  const [selectedConversation, setSelectedConversation] = useState(null);

  const renderMainContent = () => {
    switch (activeView) {
      case "conversations":
        return (
          <div className="flex h-full">
            <div className="w-80 border-r border-gray-200 bg-white">
              <ConversationList 
                onSelectConversation={setSelectedConversation}
                selectedConversation={selectedConversation}
              />
            </div>
            <div className="flex-1 flex">
              <div className="flex-1">
                <ChatInterface conversation={selectedConversation || {}} />
              </div>
              {selectedConversation && (
                <div className="w-80 border-l border-gray-200">
                  <CustomerProfile conversation={selectedConversation} />
                </div>
              )}
            </div>
          </div>
        );
      case "customers":
        return <CustomerProfile conversation={{}} />;
      case "analytics":
        return <Analytics />;
      case "settings":
        return <Settings />;
      default:
        return <div>Select a view</div>;
    }
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gray-50">
        <AppSidebar activeView={activeView} onViewChange={setActiveView} />
        <div className="flex-1 flex flex-col">
          <Header />
          <main className="flex-1 overflow-hidden">
            {renderMainContent()}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default Index;
