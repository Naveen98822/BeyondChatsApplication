
import { useState } from "react";
import { Clock, Star, Archive, Filter, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

const conversations = [
  {
    id: 1,
    customer: "Sarah Chen",
    avatar: "SC",
    subject: "Payment issue with subscription",
    preview: "Hi, I'm having trouble with my monthly subscription payment...",
    timestamp: "2 min ago",
    status: "urgent",
    unread: true,
    priority: "high",
    tags: ["billing", "subscription"]
  },
  {
    id: 2,
    customer: "Michael Rodriguez",
    avatar: "MR",
    subject: "Feature request for mobile app",
    preview: "Would love to see push notifications added to the mobile...",
    timestamp: "15 min ago",
    status: "open",
    unread: true,
    priority: "medium",
    tags: ["feature", "mobile"]
  },
  {
    id: 3,
    customer: "Emma Thompson",
    avatar: "ET",
    subject: "Login issues after recent update",
    preview: "Since the latest update, I can't seem to log into my account...",
    timestamp: "1 hour ago",
    status: "pending",
    unread: false,
    priority: "high",
    tags: ["technical", "login"]
  },
  {
    id: 4,
    customer: "David Kim",
    avatar: "DK",
    subject: "Thank you for excellent support!",
    preview: "Just wanted to thank your team for the amazing help yesterday...",
    timestamp: "3 hours ago",
    status: "closed",
    unread: false,
    priority: "low",
    tags: ["feedback", "positive"]
  },
  {
    id: 5,
    customer: "Lisa Johnson",
    avatar: "LJ",
    subject: "Integration with Slack not working",
    preview: "The Slack integration stopped working this morning...",
    timestamp: "5 hours ago",
    status: "open",
    unread: true,
    priority: "medium",
    tags: ["integration", "slack"]
  }
];

const statusColors = {
  urgent: "bg-red-100 text-red-700",
  open: "bg-green-100 text-green-700",
  pending: "bg-yellow-100 text-yellow-700",
  closed: "bg-gray-100 text-gray-700"
};

const priorityColors = {
  high: "border-l-red-500",
  medium: "border-l-yellow-500",
  low: "border-l-green-500"
};

export function ConversationList({ onSelectConversation, selectedConversation }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  const filteredConversations = conversations.filter(conv => {
    const matchesSearch = conv.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         conv.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === "all" || conv.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="h-full flex flex-col bg-white">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-gray-900">Conversations</h2>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <Filter className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Archive className="w-4 h-4" />
            </Button>
          </div>
        </div>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search conversations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-gray-50 border-gray-200"
          />
        </div>

        <div className="flex space-x-2 mt-3">
          {["all", "open", "pending", "urgent", "closed"].map((status) => (
            <Button
              key={status}
              variant={filterStatus === status ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterStatus(status)}
              className="text-xs capitalize"
            >
              {status}
            </Button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {filteredConversations.map((conversation) => (
          <div
            key={conversation.id}
            onClick={() => onSelectConversation(conversation)}
            className={`p-4 border-b border-gray-100 cursor-pointer transition-all duration-200 border-l-4 ${
              priorityColors[conversation.priority]
            } ${
              selectedConversation?.id === conversation.id
                ? "bg-blue-50 border-r-2 border-r-blue-500"
                : "hover:bg-gray-50"
            }`}
          >
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-medium text-sm">
                  {conversation.avatar}
                </div>
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="text-sm font-medium text-gray-900 truncate">
                    {conversation.customer}
                  </h3>
                  <div className="flex items-center space-x-1">
                    {conversation.unread && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    )}
                    <Clock className="w-3 h-3 text-gray-400" />
                    <span className="text-xs text-gray-500">{conversation.timestamp}</span>
                  </div>
                </div>
                
                <p className="text-sm font-medium text-gray-700 mb-1 truncate">
                  {conversation.subject}
                </p>
                
                <p className="text-xs text-gray-500 mb-2 line-clamp-2">
                  {conversation.preview}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Badge className={`text-xs ${statusColors[conversation.status]}`}>
                      {conversation.status}
                    </Badge>
                    {conversation.tags.slice(0, 2).map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  {conversation.priority === "high" && (
                    <Star className="w-4 h-4 text-yellow-500" />
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
