
import { useState } from "react";
import { MessageSquare, Users, BarChart3, Settings, Bot, Zap, Star } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const menuItems = [
  { id: "conversations", title: "Conversations", icon: MessageSquare, badge: "23" },
  { id: "customers", title: "Customers", icon: Users },
  { id: "analytics", title: "Analytics", icon: BarChart3 },
  { id: "settings", title: "Settings", icon: Settings },
];

const aiFeatures = [
  { id: "ai-assist", title: "AI Assistant", icon: Bot, badge: "New" },
  { id: "automations", title: "Automations", icon: Zap },
  { id: "insights", title: "AI Insights", icon: Star },
];

export function AppSidebar({ activeView, onViewChange }) {
  return (
    <Sidebar className="w-64 border-r border-gray-200 bg-white">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <MessageSquare className="w-5 h-5 text-white" />
          </div>
          <span className="font-semibold text-gray-900">BeyondChats</span>
        </div>
        <SidebarTrigger className="mt-2" />
      </div>

      <SidebarContent className="px-3 py-4">
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-medium text-gray-500 uppercase tracking-wider">
            Main
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton
                    onClick={() => onViewChange(item.id)}
                    className={`w-full justify-start transition-all duration-200 ${
                      activeView === item.id
                        ? "bg-blue-50 text-blue-700 border-r-2 border-blue-700"
                        : "text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    <item.icon className="h-5 w-5" />
                    <div className="flex items-center justify-between w-full">
                      <span>{item.title}</span>
                      {item.badge && (
                        <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full">
                          {item.badge}
                        </span>
                      )}
                    </div>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="mt-6">
          <SidebarGroupLabel className="text-xs font-medium text-gray-500 uppercase tracking-wider">
            AI Features
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {aiFeatures.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton
                    onClick={() => onViewChange(item.id)}
                    className="w-full justify-start text-gray-700 hover:bg-gray-50 transition-all duration-200"
                  >
                    <item.icon className="h-5 w-5" />
                    <div className="flex items-center justify-between w-full">
                      <span>{item.title}</span>
                      {item.badge && (
                        <span className="bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 text-xs px-2 py-1 rounded-full">
                          {item.badge}
                        </span>
                      )}
                    </div>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <div className="p-4 border-t border-gray-200">
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-3 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Bot className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-gray-900">AI Usage</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full w-3/4"></div>
          </div>
          <p className="text-xs text-gray-600 mt-1">750/1000 AI responses</p>
        </div>
      </div>
    </Sidebar>
  );
}
