
import { Mail, Phone, MapPin, Calendar, Star, Tag, Clock, CreditCard } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export function CustomerProfile({ conversation }) {
  if (!conversation) {
    return (
      <div className="h-full bg-white border-l border-gray-200 p-6">
        <div className="text-center text-gray-500">
          <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto mb-4 flex items-center justify-center">
            <span className="text-2xl">👤</span>
          </div>
          <p>Select a conversation to view customer details</p>
        </div>
      </div>
    );
  }

  const customerData = {
    name: conversation.customer,
    email: "sarah.chen@email.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA",
    joinDate: "March 2024",
    plan: "Pro Plan",
    status: "Active",
    totalSpent: "$480",
    conversations: 12,
    avgResponseTime: "4 hours",
    satisfaction: 4.8,
    tags: ["VIP", "Billing Expert", "Early Adopter"],
    recentActivity: [
      { action: "Logged in", time: "2 hours ago" },
      { action: "Updated payment method", time: "1 day ago" },
      { action: "Downloaded invoice", time: "3 days ago" },
      { action: "Contacted support", time: "1 week ago" }
    ]
  };

  return (
    <div className="h-full bg-white overflow-y-auto">
      <div className="p-6">
        {/* Customer Header */}
        <div className="text-center mb-6">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full mx-auto mb-4 flex items-center justify-center text-white text-2xl font-bold">
            {conversation.avatar}
          </div>
          <h2 className="text-xl font-semibold text-gray-900">{customerData.name}</h2>
          <p className="text-gray-500">{customerData.email}</p>
          <div className="flex justify-center space-x-2 mt-3">
            <Badge className="bg-green-100 text-green-700">{customerData.status}</Badge>
            <Badge variant="outline">{customerData.plan}</Badge>
          </div>
        </div>

        <Separator className="my-6" />

        {/* Contact Information */}
        <div className="space-y-4 mb-6">
          <h3 className="font-medium text-gray-900">Contact Information</h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <Mail className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">{customerData.email}</span>
            </div>
            <div className="flex items-center space-x-3">
              <Phone className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">{customerData.phone}</span>
            </div>
            <div className="flex items-center space-x-3">
              <MapPin className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">{customerData.location}</span>
            </div>
            <div className="flex items-center space-x-3">
              <Calendar className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">Joined {customerData.joinDate}</span>
            </div>
          </div>
        </div>

        <Separator className="my-6" />

        {/* Account Stats */}
        <div className="space-y-4 mb-6">
          <h3 className="font-medium text-gray-900">Account Overview</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="flex items-center space-x-2">
                <CreditCard className="w-4 h-4 text-blue-500" />
                <span className="text-xs font-medium text-gray-500">Total Spent</span>
              </div>
              <p className="text-lg font-semibold text-gray-900 mt-1">{customerData.totalSpent}</p>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-green-500" />
                <span className="text-xs font-medium text-gray-500">Avg Response</span>
              </div>
              <p className="text-lg font-semibold text-gray-900 mt-1">{customerData.avgResponseTime}</p>
            </div>
          </div>
          
          <div className="bg-gray-50 p-3 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Star className="w-4 h-4 text-yellow-500" />
                <span className="text-sm font-medium text-gray-700">Satisfaction Score</span>
              </div>
              <div className="flex items-center space-x-1">
                <span className="text-lg font-semibold text-gray-900">{customerData.satisfaction}</span>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-3 h-3 ${
                        star <= customerData.satisfaction ? "text-yellow-400 fill-current" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-6" />

        {/* Tags */}
        <div className="space-y-4 mb-6">
          <h3 className="font-medium text-gray-900">Customer Tags</h3>
          <div className="flex flex-wrap gap-2">
            {customerData.tags.map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs">
                <Tag className="w-3 h-3 mr-1" />
                {tag}
              </Badge>
            ))}
          </div>
          <Button variant="outline" size="sm" className="w-full">
            Add Tag
          </Button>
        </div>

        <Separator className="my-6" />

        {/* Recent Activity */}
        <div className="space-y-4">
          <h3 className="font-medium text-gray-900">Recent Activity</h3>
          <div className="space-y-3">
            {customerData.recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <div className="flex-1">
                  <p className="text-sm text-gray-900">{activity.action}</p>
                  <p className="text-xs text-gray-500">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-6 space-y-2">
          <Button className="w-full" variant="outline">
            View Full History
          </Button>
          <Button className="w-full" variant="outline">
            Send Email
          </Button>
          <Button className="w-full" variant="outline">
            Schedule Call
          </Button>
        </div>
      </div>
    </div>
  );
}
