
import { Bell, Shield, User, Palette, Bot, Zap } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";

export function Settings() {
  return (
    <div className="p-6 bg-gray-50 min-h-full">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">Settings</h1>
        <p className="text-gray-600">Manage your account and application preferences</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profile Settings */}
        <Card className="bg-white">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="w-5 h-5" />
              <span>Profile Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input id="name" defaultValue="John Doe" />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" defaultValue="john.doe@company.com" />
            </div>
            <div>
              <Label htmlFor="role">Role</Label>
              <Input id="role" defaultValue="Customer Support Manager" />
            </div>
            <Button className="w-full">Update Profile</Button>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card className="bg-white">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bell className="w-5 h-5" />
              <span>Notifications</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="email-notifications">Email Notifications</Label>
              <Switch id="email-notifications" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="push-notifications">Push Notifications</Label>
              <Switch id="push-notifications" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="urgent-alerts">Urgent Conversation Alerts</Label>
              <Switch id="urgent-alerts" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="daily-digest">Daily Digest</Label>
              <Switch id="daily-digest" />
            </div>
          </CardContent>
        </Card>

        {/* AI Settings */}
        <Card className="bg-white">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bot className="w-5 h-5" />
              <span>AI Assistant</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="ai-suggestions">Enable AI Suggestions</Label>
              <Switch id="ai-suggestions" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="auto-responses">Auto-Response Suggestions</Label>
              <Switch id="auto-responses" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="sentiment-analysis">Sentiment Analysis</Label>
              <Switch id="sentiment-analysis" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="conversation-insights">Conversation Insights</Label>
              <Switch id="conversation-insights" />
            </div>
            <Separator />
            <div className="p-3 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Zap className="w-4 h-4 text-purple-600" />
                <span className="text-sm font-medium text-purple-700">AI Usage</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                <div className="bg-gradient-to-r from-purple-500 to-blue-500 h-2 rounded-full w-3/4"></div>
              </div>
              <p className="text-xs text-gray-600">750/1000 AI responses this month</p>
            </div>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card className="bg-white">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="w-5 h-5" />
              <span>Security</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="two-factor">Two-Factor Authentication</Label>
              <Switch id="two-factor" />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="login-alerts">Login Alerts</Label>
              <Switch id="login-alerts" defaultChecked />
            </div>
            <Separator />
            <Button variant="outline" className="w-full">
              Change Password
            </Button>
            <Button variant="outline" className="w-full">
              Download Account Data
            </Button>
          </CardContent>
        </Card>

        {/* Appearance Settings */}
        <Card className="bg-white lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Palette className="w-5 h-5" />
              <span>Appearance</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 border-2 border-blue-500 rounded-lg bg-blue-50">
                <div className="w-full h-20 bg-white rounded mb-3 flex items-center justify-center">
                  <span className="text-sm text-gray-600">Light Theme</span>
                </div>
                <p className="text-sm font-medium text-center">Current</p>
              </div>
              <div className="p-4 border rounded-lg hover:border-gray-400 cursor-pointer">
                <div className="w-full h-20 bg-gray-800 rounded mb-3 flex items-center justify-center">
                  <span className="text-sm text-white">Dark Theme</span>
                </div>
                <p className="text-sm font-medium text-center">Coming Soon</p>
              </div>
              <div className="p-4 border rounded-lg hover:border-gray-400 cursor-pointer">
                <div className="w-full h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded mb-3 flex items-center justify-center">
                  <span className="text-sm text-white">Auto</span>
                </div>
                <p className="text-sm font-medium text-center">System</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
