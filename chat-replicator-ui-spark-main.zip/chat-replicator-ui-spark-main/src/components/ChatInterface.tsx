
import { useState } from "react";
import { Send, Paperclip, Smile, MoreHorizontal, Bot, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

interface Message {
  id: number;
  type: string;
  content: string;
  timestamp: string;
  status?: string;
  suggested?: boolean;
}

const initialMessages: Message[] = [
  {
    id: 1,
    type: "customer",
    content: "Hi, I'm having trouble with my recent order. It hasn't arrived yet and it's been 5 days.",
    timestamp: "2:30 PM",
    status: "delivered"
  },
  {
    id: 2,
    type: "agent",
    content: "I'm sorry to hear about the delay with your order. Let me look into this for you right away. Can you please provide me with your order number?",
    timestamp: "2:32 PM",
    status: "delivered"
  },
  {
    id: 3,
    type: "ai-suggestion",
    content: "Suggested response: I've checked your order #12345 and I can see it's currently in transit. The estimated delivery is tomorrow by 6 PM. I'll send you a tracking link right now.",
    timestamp: "2:33 PM",
    suggested: true
  }
];

export function ChatInterface({ conversation }: { conversation?: any }) {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [newMessage, setNewMessage] = useState("");

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const message: Message = {
        id: messages.length + 1,
        type: "agent",
        content: newMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: "delivered"
      };
      
      setMessages(prev => [...prev, message]);
      setNewMessage("");

      // Simulate AI suggestion after agent message
      setTimeout(() => {
        const aiSuggestion: Message = {
          id: messages.length + 2,
          type: "ai-suggestion",
          content: "Suggested follow-up: Would you like me to expedite the shipping for your next order at no extra cost?",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggested: true
        };
        setMessages(prev => [...prev, aiSuggestion]);
      }, 1000);
    }
  };

  const acceptSuggestion = (suggestionId: number) => {
    const suggestion = messages.find(m => m.id === suggestionId);
    if (suggestion) {
      const newAgentMessage: Message = {
        id: messages.length + 1,
        type: "agent",
        content: suggestion.content.replace("Suggested response: ", "").replace("Suggested follow-up: ", ""),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: "delivered"
      };
      
      setMessages(prev => [...prev.filter(m => m.id !== suggestionId), newAgentMessage]);
    }
  };

  if (!conversation) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
            <Bot className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Select a conversation</h3>
          <p className="text-gray-500">Choose a conversation from the sidebar to start chatting</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-white">
      {/* Chat Header */}
      <div className="h-16 border-b border-gray-200 px-6 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
            <User className="w-5 h-5 text-green-600" />
          </div>
          <div>
            <h3 className="font-medium text-gray-900">Sarah Johnson</h3>
            <p className="text-sm text-green-600">● Online</p>
          </div>
        </div>
        <Button variant="ghost" size="sm">
          <MoreHorizontal className="w-5 h-5" />
        </Button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.type === 'agent' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs lg:max-w-md ${
              message.type === 'customer' 
                ? 'bg-gray-100 text-gray-900' 
                : message.type === 'ai-suggestion'
                ? 'bg-purple-50 border border-purple-200 text-purple-900'
                : 'bg-blue-600 text-white'
            } rounded-lg px-4 py-2`}>
              {message.type === 'ai-suggestion' && (
                <div className="flex items-center space-x-2 mb-2">
                  <Bot className="w-4 h-4 text-purple-600" />
                  <span className="text-xs font-medium text-purple-600">AI Suggestion</span>
                </div>
              )}
              <p className="text-sm">{message.content}</p>
              <div className="flex items-center justify-between mt-2">
                <span className="text-xs opacity-70">{message.timestamp}</span>
                {message.type === 'ai-suggestion' && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs ml-2"
                    onClick={() => acceptSuggestion(message.id)}
                  >
                    Use
                  </Button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Message Input */}
      <div className="border-t border-gray-200 p-4">
        <div className="flex items-end space-x-2">
          <div className="flex-1">
            <Textarea
              placeholder="Type your message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              className="resize-none min-h-[40px] max-h-32"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
            />
          </div>
          <div className="flex space-x-1">
            <Button variant="ghost" size="sm">
              <Paperclip className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Smile className="w-4 h-4" />
            </Button>
            <Button onClick={handleSendMessage} size="sm">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
