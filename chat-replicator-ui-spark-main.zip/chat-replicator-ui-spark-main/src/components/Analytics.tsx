
import { TrendingUp, Users, MessageSquare, Clock, Star, ArrowUp, ArrowDown } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export function Analytics() {
  const metrics = [
    {
      title: "Total Conversations",
      value: "2,847",
      change: "+12.5%",
      trend: "up",
      icon: MessageSquare,
      description: "vs last month"
    },
    {
      title: "Active Customers", 
      value: "1,923",
      change: "+8.3%",
      trend: "up",
      icon: Users,
      description: "vs last month"
    },
    {
      title: "Avg Response Time",
      value: "2.4 hrs",
      change: "-15.2%",
      trend: "down",
      icon: Clock,
      description: "vs last month"
    },
    {
      title: "Customer Satisfaction",
      value: "4.8/5",
      change: "+0.2",
      trend: "up", 
      icon: Star,
      description: "vs last month"
    }
  ];

  const conversationStats = [
    { status: "Open", count: 156, color: "bg-blue-500" },
    { status: "Pending", count: 89, color: "bg-yellow-500" },
    { status: "Urgent", count: 23, color: "bg-red-500" },
    { status: "Closed", count: 1247, color: "bg-green-500" }
  ];

  const topAgents = [
    { name: "John Doe", conversations: 89, satisfaction: 4.9, responseTime: "1.2 hrs" },
    { name: "Sarah Smith", conversations: 76, satisfaction: 4.8, responseTime: "1.5 hrs" },
    { name: "Mike Johnson", conversations: 65, satisfaction: 4.7, responseTime: "2.1 hrs" },
    { name: "Emily Davis", conversations: 58, satisfaction: 4.6, responseTime: "2.4 hrs" }
  ];

  return (
    <div className="p-6 bg-gray-50 min-h-full">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">Analytics Dashboard</h1>
        <p className="text-gray-600">Monitor your customer support performance and metrics</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {metrics.map((metric) => (
          <Card key={metric.title} className="bg-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-50 rounded-lg">
                    <metric.icon className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                    <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
                  </div>
                </div>
              </div>
              <div className="mt-4 flex items-center space-x-2">
                <Badge className={`${metric.trend === "up" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                  {metric.trend === "up" ? (
                    <ArrowUp className="w-3 h-3 mr-1" />
                  ) : (
                    <ArrowDown className="w-3 h-3 mr-1" />
                  )}
                  {metric.change}
                </Badge>
                <span className="text-sm text-gray-500">{metric.description}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Conversation Status Overview */}
        <Card className="bg-white">
          <CardHeader>
            <CardTitle>Conversation Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {conversationStats.map((stat) => (
                <div key={stat.status} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${stat.color}`}></div>
                    <span className="text-sm font-medium text-gray-700">{stat.status}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="text-sm font-semibold text-gray-900">{stat.count}</span>
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${stat.color}`}
                        style={{ width: `${(stat.count / 1515) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Top Performing Agents */}
        <Card className="bg-white">
          <CardHeader>
            <CardTitle>Top Performing Agents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topAgents.map((agent, index) => (
                <div key={agent.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-medium text-sm">
                      {index + 1}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">{agent.name}</p>
                      <p className="text-xs text-gray-500">{agent.conversations} conversations</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3 text-yellow-400 fill-current" />
                      <span className="text-sm font-semibold text-gray-900">{agent.satisfaction}</span>
                    </div>
                    <p className="text-xs text-gray-500">{agent.responseTime}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Performance Metrics */}
      <Card className="bg-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <span>AI Performance Insights</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600 mb-2">89%</div>
              <div className="text-sm text-gray-600">AI Suggestions Accepted</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-green-50 to-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600 mb-2">-34%</div>
              <div className="text-sm text-gray-600">Response Time Improvement</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600 mb-2">96%</div>
              <div className="text-sm text-gray-600">Customer Issue Resolution</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
